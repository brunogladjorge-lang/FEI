#include "dados.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const char *SIMBOLOS[3] = {"BTC", "ETH", "XRP"};
const char *NOMES[3] = {"Bitcoin", "Ethereum", "Ripple"};

void agora(char *buf, size_t n, const char *fmt) {
    time_t t = time(NULL);
    strftime(buf, n, fmt, localtime(&t));
}

/* ---------- Usuarios ---------- */
void carregar_usuarios(Banco *b) {
    b->n = 0;
    b->cap = 16;
    b->v = malloc(sizeof(Usuario) * (size_t)b->cap);
    FILE *f = fopen(ARQ_USUARIOS, "r");
    if (!f) return;
    char linha[512];
    while (fgets(linha, sizeof linha, f)) {
        Usuario u;
        memset(&u, 0, sizeof u);
        int r = sscanf(linha,
                       "%11[^|]|%63[^|]|%16[^|]|%64[^|]|%16[^|]|%d|%lld|%lf|%lf|%lf|%lf|%lf|%lf|%lf|%d",
                       u.cpf, u.nome, u.salt, u.hash, u.segredo, &u.falhas, &u.bloqueio, &u.reais,
                       &u.cripto[0], &u.cripto[1], &u.cripto[2], &u.pm[0], &u.pm[1], &u.pm[2], &u.ops);
        if (r == 15) adicionar(b, &u);
    }
    fclose(f);
}

void adicionar(Banco *b, const Usuario *u) {
    if (b->n == b->cap) {
        b->cap *= 2;
        b->v = realloc(b->v, sizeof(Usuario) * (size_t)b->cap);
    }
    b->v[b->n++] = *u;
}

/* Grava num arquivo temporario e so depois troca: nunca corrompe o original.
   Mantem usuarios.bak com a versao anterior. */
void salvar_usuarios(const Banco *b) {
    FILE *f = fopen(ARQ_USUARIOS ".tmp", "w");
    if (!f) { puts("Erro ao salvar usuarios!"); return; }
    for (int i = 0; i < b->n; i++) {
        const Usuario *u = &b->v[i];
        fprintf(f, "%s|%s|%s|%s|%s|%d|%lld|%.2f|%.8f|%.8f|%.8f|%.6f|%.6f|%.6f|%d\n", u->cpf, u->nome,
                u->salt, u->hash, u->segredo, u->falhas, u->bloqueio, u->reais, u->cripto[0],
                u->cripto[1], u->cripto[2], u->pm[0], u->pm[1], u->pm[2], u->ops);
    }
    fclose(f);
    remove(ARQ_USUARIOS ".bak");
    rename(ARQ_USUARIOS, ARQ_USUARIOS ".bak");
    rename(ARQ_USUARIOS ".tmp", ARQ_USUARIOS);
}

Usuario *buscar(Banco *b, const char *cpf) {
    for (int i = 0; i < b->n; i++)
        if (strcmp(b->v[i].cpf, cpf) == 0) return &b->v[i];
    return NULL;
}

/* ---------- Extrato ---------- */
void registrar_extrato(const Usuario *u, char sinal, double valor, int moeda, double ct, double tx) {
    FILE *f = fopen(ARQ_EXTRATO, "a");
    if (!f) return;
    char d[32];
    agora(d, sizeof d, "%d-%m-%Y %H:%M");
    fprintf(f, "%s|%s|%c|%.8f|%s|%.4f|%.2f|%.2f|%.8f|%.8f|%.8f\n", u->cpf, d, sinal, valor,
            moeda < 0 ? "REAL" : SIMBOLOS[moeda], ct, tx, u->reais, u->cripto[0], u->cripto[1],
            u->cripto[2]);
    fclose(f);
}

int ler_extrato(const char *cpf, LinhaExtrato **out) {
    int n = 0, cap = 32;
    LinhaExtrato *v = malloc(sizeof(LinhaExtrato) * (size_t)cap);
    FILE *f = fopen(ARQ_EXTRATO, "r");
    if (f) {
        char linha[512];
        while (fgets(linha, sizeof linha, f)) {
            LinhaExtrato l;
            memset(&l, 0, sizeof l);
            int r = sscanf(linha, "%11[^|]|%19[^|]|%c|%lf|%7[^|]|%lf|%lf|%lf|%lf|%lf|%lf", l.cpf, l.data,
                           &l.sinal, &l.valor, l.moeda, &l.ct, &l.tx, &l.reais, &l.c[0], &l.c[1], &l.c[2]);
            if (r != 11 || strcmp(l.cpf, cpf) != 0) continue;
            if (n == cap) { cap *= 2; v = realloc(v, sizeof(LinhaExtrato) * (size_t)cap); }
            v[n++] = l;
        }
        fclose(f);
    }
    *out = v;
    return n;
}

/* ---------- Auditoria ---------- */
void log_audit(const char *cpf, const char *evento) {
    FILE *f = fopen(ARQ_AUDIT, "a");
    if (!f) return;
    char d[32];
    agora(d, sizeof d, "%d-%m-%Y %H:%M:%S");
    fprintf(f, "%s|%s|%s\n", d, cpf && *cpf ? cpf : "-", evento);
    fclose(f);
}

/* ---------- Cotacoes ---------- */
int historico(double (*h)[3], int max) {
    FILE *f = fopen(ARQ_COTACOES, "r");
    if (!f) return 0;
    int n = 0;
    double a, b, c;
    while (fscanf(f, "%lf %lf %lf", &a, &b, &c) == 3) {
        if (n == max) { memmove(h, h + 1, sizeof(double) * 3 * (size_t)(max - 1)); n--; }
        h[n][0] = a; h[n][1] = b; h[n][2] = c;
        n++;
    }
    fclose(f);
    return n;
}

void gravar_cotacao(const double c[3]) {
    FILE *f = fopen(ARQ_COTACOES, "a");
    if (!f) return;
    fprintf(f, "%.4f %.4f %.4f\n", c[0], c[1], c[2]);
    fclose(f);
}

void carregar_cotacao(double c[3]) {
    double h[1][3];
    if (historico(h, 1) == 1) {
        c[0] = h[0][0]; c[1] = h[0][1]; c[2] = h[0][2];
    } else {                               /* primeira execucao */
        c[0] = 350000.0; c[1] = 15000.0; c[2] = 3.0;
        gravar_cotacao(c);
    }
}

/* ---------- Exportacao para o painel web ---------- */
void exportar_json(const Usuario *u, const double cot[3], const char *nivel) {
    FILE *f = fopen(ARQ_JSON, "w");
    if (!f) { puts("Nao foi possivel criar dados.json"); return; }
    fprintf(f, "{\n\"nome\":\"%s\",\"cpf\":\"%s\",\"nivel\":\"%s\",\n", u->nome, u->cpf, nivel);
    fprintf(f, "\"saldo\":{\"reais\":%.2f,\"btc\":%.8f,\"eth\":%.8f,\"xrp\":%.8f},\n", u->reais,
            u->cripto[0], u->cripto[1], u->cripto[2]);
    fprintf(f, "\"cotacao\":{\"btc\":%.4f,\"eth\":%.4f,\"xrp\":%.4f},\n\"extrato\":[", cot[0], cot[1], cot[2]);

    LinhaExtrato *v;
    int n = ler_extrato(u->cpf, &v);
    for (int i = 0; i < n; i++)
        fprintf(f,
                "%s\n{\"data\":\"%s\",\"sinal\":\"%c\",\"valor\":%.8f,\"moeda\":\"%s\",\"ct\":%.4f,"
                "\"tx\":%.2f,\"reais\":%.2f,\"btc\":%.8f,\"eth\":%.8f,\"xrp\":%.8f}",
                i ? "," : "", v[i].data, v[i].sinal, v[i].valor, v[i].moeda, v[i].ct, v[i].tx,
                v[i].reais, v[i].c[0], v[i].c[1], v[i].c[2]);
    free(v);

    fprintf(f, "\n],\n\"historico\":[");
    double h[200][3];
    int m = historico(h, 200);
    for (int i = 0; i < m; i++) fprintf(f, "%s[%.4f,%.4f,%.4f]", i ? "," : "", h[i][0], h[i][1], h[i][2]);
    fprintf(f, "]\n}\n");
    fclose(f);
}
