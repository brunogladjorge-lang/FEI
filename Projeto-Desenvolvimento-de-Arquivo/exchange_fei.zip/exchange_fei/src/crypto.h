#ifndef CRYPTO_H
#define CRYPTO_H
#include <stdint.h>
#include <stddef.h>

/* Hash e HMAC */
void sha1(const uint8_t *msg, size_t len, uint8_t out[20]);
void hmac_sha1(const uint8_t *key, size_t kl, const uint8_t *msg, size_t ml, uint8_t out[20]);
void sha256_hex(const char *texto, char out[65]);

/* Base32 (RFC 4648) usado no segredo do 2FA */
void base32_encode(const uint8_t *in, size_t n, char *out);
size_t base32_decode(const char *in, uint8_t *out, size_t max);

/* TOTP (RFC 6238): codigo de 6 digitos que muda a cada 30 segundos */
uint32_t totp(const uint8_t *key, size_t kl, uint64_t contador);
int totp_verificar(const char *segredo_b32, const char *codigo);

/* Bytes aleatorios do sistema operacional */
void bytes_aleatorios(uint8_t *buf, size_t n);

#endif
