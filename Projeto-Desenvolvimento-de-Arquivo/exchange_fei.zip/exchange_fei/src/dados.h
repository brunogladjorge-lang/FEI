#ifndef DADOS_H
#define DADOS_H
#include <stddef.h>

#define ARQ_USUARIOS "usuarios.txt"
#define ARQ_EXTRATO  "extrato.txt"
#define ARQ_COTACOES "cotacoes.txt"
#define ARQ_AUDIT    "auditoria.txt"
#define ARQ_JSON     "dados.json"

extern const char *SIMBOLOS[3]; /* BTC, ETH, XRP */
extern const char *NOMES[3];

typedef struct {
    char cpf[12], nome[64], salt[17], hash[65], segredo[17];
    int falhas;
    long long bloqueio;   /* epoch ate quando a conta fica bloqueada */
    double reais;
    double cripto[3];     /* BTC, ETH, XRP */
    double pm[3];         /* preco medio de compra */
    int ops;              /* numero de operacoes (define o nivel) */
} Usuario;

typedef struct { Usuario *v; int n, cap; } Banco;

typedef struct {
    char cpf[12], data[20], sinal, moeda[8];
    double valor, ct, tx, reais, c[3];
} LinhaExtrato;

void agora(char *buf, size_t n, const char *fmt);

void carregar_usuarios(Banco *b);
void salvar_usuarios(const Banco *b);
Usuario *buscar(Banco *b, const char *cpf);
void adicionar(Banco *b, const Usuario *u);

/* moeda: -1 = REAL, 0..2 = BTC/ETH/XRP */
void registrar_extrato(const Usuario *u, char sinal, double valor, int moeda, double ct, double tx);
int ler_extrato(const char *cpf, LinhaExtrato **out);

void log_audit(const char *cpf, const char *evento);

void carregar_cotacao(double c[3]);
void gravar_cotacao(const double c[3]);
int historico(double (*h)[3], int max);

void exportar_json(const Usuario *u, const double cot[3], const char *nivel);

#endif
