#ifdef _WIN32
#define _CRT_RAND_S
#endif
#include "crypto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static uint32_t rol(uint32_t v, int b) { return (v << b) | (v >> (32 - b)); }

void sha1(const uint8_t *msg, size_t len, uint8_t out[20])
{
    uint32_t h[5] = {0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0};
    size_t total = ((len + 8) / 64 + 1) * 64;
    uint8_t *p = calloc(total, 1);
    memcpy(p, msg, len);
    p[len] = 0x80;
    uint64_t bits = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++)
        p[total - 1 - i] = (uint8_t)(bits >> (8 * i));

    for (size_t off = 0; off < total; off += 64)
    {
        uint32_t w[80];
        for (int i = 0; i < 16; i++)
            w[i] = ((uint32_t)p[off + 4 * i] << 24) | ((uint32_t)p[off + 4 * i + 1] << 16) |
                   ((uint32_t)p[off + 4 * i + 2] << 8) | (uint32_t)p[off + 4 * i + 3];
        for (int i = 16; i < 80; i++)
            w[i] = rol(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1);

        uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4];
        for (int i = 0; i < 80; i++)
        {
            uint32_t f, k;
            if (i < 20)
            {
                f = (b & c) | (~b & d);
                k = 0x5A827999;
            }
            else if (i < 40)
            {
                f = b ^ c ^ d;
                k = 0x6ED9EBA1;
            }
            else if (i < 60)
            {
                f = (b & c) | (b & d) | (c & d);
                k = 0x8F1BBCDC;
            }
            else
            {
                f = b ^ c ^ d;
                k = 0xCA62C1D6;
            }
            uint32_t t = rol(a, 5) + f + e + k + w[i];
            e = d;
            d = c;
            c = rol(b, 30);
            b = a;
            a = t;
        }
        h[0] += a;
        h[1] += b;
        h[2] += c;
        h[3] += d;
        h[4] += e;
    }
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 4; j++)
            out[i * 4 + j] = (uint8_t)(h[i] >> (24 - 8 * j));
    free(p);
}

void hmac_sha1(const uint8_t *key, size_t kl, const uint8_t *msg, size_t ml, uint8_t out[20])
{
    uint8_t k[64] = {0};
    if (kl > 64)
        sha1(key, kl, k);
    else
        memcpy(k, key, kl);

    uint8_t *in = malloc(64 + ml);
    for (int i = 0; i < 64; i++)
        in[i] = k[i] ^ 0x36;
    memcpy(in + 64, msg, ml);
    uint8_t interno[20];
    sha1(in, 64 + ml, interno);
    free(in);

    uint8_t ext[64 + 20];
    for (int i = 0; i < 64; i++)
        ext[i] = k[i] ^ 0x5c;
    memcpy(ext + 64, interno, 20);
    sha1(ext, sizeof ext, out);
}

static uint32_t ror(uint32_t v, int b) { return (v >> b) | (v << (32 - b)); }

static const uint32_t K256[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

void sha256_hex(const char *texto, char out[65])
{
    uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                     0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
    size_t len = strlen(texto);
    size_t total = ((len + 8) / 64 + 1) * 64;
    uint8_t *p = calloc(total, 1);
    memcpy(p, texto, len);
    p[len] = 0x80;
    uint64_t bits = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++)
        p[total - 1 - i] = (uint8_t)(bits >> (8 * i));

    for (size_t off = 0; off < total; off += 64)
    {
        uint32_t w[64];
        for (int i = 0; i < 16; i++)
            w[i] = ((uint32_t)p[off + 4 * i] << 24) | ((uint32_t)p[off + 4 * i + 1] << 16) |
                   ((uint32_t)p[off + 4 * i + 2] << 8) | (uint32_t)p[off + 4 * i + 3];
        for (int i = 16; i < 64; i++)
        {
            uint32_t s0 = ror(w[i - 15], 7) ^ ror(w[i - 15], 18) ^ (w[i - 15] >> 3);
            uint32_t s1 = ror(w[i - 2], 17) ^ ror(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }
        uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
        for (int i = 0; i < 64; i++)
        {
            uint32_t S1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25);
            uint32_t ch = (e & f) ^ (~e & g);
            uint32_t t1 = hh + S1 + ch + K256[i] + w[i];
            uint32_t S0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            hh = g;
            g = f;
            f = e;
            e = d + t1;
            d = c;
            c = b;
            b = a;
            a = t1 + t2;
        }
        h[0] += a;
        h[1] += b;
        h[2] += c;
        h[3] += d;
        h[4] += e;
        h[5] += f;
        h[6] += g;
        h[7] += hh;
    }
    for (int i = 0; i < 8; i++)
        snprintf(out + 8 * i, 9, "%08x", h[i]);
    free(p);
}

static const char B32[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

void base32_encode(const uint8_t *in, size_t n, char *out)
{
    uint32_t buf = 0;
    int bits = 0;
    size_t o = 0;
    for (size_t i = 0; i < n; i++)
    {
        buf = (buf << 8) | in[i];
        bits += 8;
        while (bits >= 5)
        {
            out[o++] = B32[(buf >> (bits - 5)) & 31];
            bits -= 5;
        }
    }
    if (bits > 0)
        out[o++] = B32[(buf << (5 - bits)) & 31];
    out[o] = 0;
}

size_t base32_decode(const char *in, uint8_t *out, size_t max)
{
    uint32_t buf = 0;
    int bits = 0;
    size_t o = 0;
    for (; *in && o < max; in++)
    {
        const char *pos = strchr(B32, *in);
        if (!pos || !*in)
            continue;
        buf = (buf << 5) | (uint32_t)(pos - B32);
        bits += 5;
        if (bits >= 8)
        {
            out[o++] = (uint8_t)(buf >> (bits - 8));
            bits -= 8;
        }
    }
    return o;
}

uint32_t totp(const uint8_t *key, size_t kl, uint64_t contador)
{
    uint8_t msg[8], h[20];
    for (int i = 7; i >= 0; i--)
    {
        msg[i] = (uint8_t)(contador & 0xff);
        contador >>= 8;
    }
    hmac_sha1(key, kl, msg, 8, h);
    int off = h[19] & 0x0f;
    uint32_t bin = ((uint32_t)(h[off] & 0x7f) << 24) | ((uint32_t)h[off + 1] << 16) |
                   ((uint32_t)h[off + 2] << 8) | (uint32_t)h[off + 3];
    return bin % 1000000;
}

int totp_verificar(const char *segredo_b32, const char *codigo)
{
    uint8_t key[32];
    size_t kl = base32_decode(segredo_b32, key, sizeof key);
    if (kl == 0 || strlen(codigo) != 6)
        return 0;
    for (int i = 0; i < 6; i++)
        if (codigo[i] < '0' || codigo[i] > '9')
            return 0;
    uint64_t agora = (uint64_t)time(NULL) / 30;
    uint32_t digitado = (uint32_t)atoi(codigo);
    for (int d = -1; d <= 1; d++) /* aceita 30s antes e depois */
        if (totp(key, kl, agora + (uint64_t)(int64_t)d) == digitado)
            return 1;
    return 0;
}

void bytes_aleatorios(uint8_t *buf, size_t n)
{
#ifdef _WIN32
    for (size_t i = 0; i < n; i++)
    {
        unsigned int r = 0;
        rand_s(&r);
        buf[i] = (uint8_t)r;
    }
#else
    FILE *f = fopen("/dev/urandom", "rb");
    if (f && fread(buf, 1, n, f) == n)
    {
        fclose(f);
        return;
    }
    if (f)
        fclose(f);
    for (size_t i = 0; i < n; i++)
        buf[i] = (uint8_t)(rand() & 0xff);
#endif
}
