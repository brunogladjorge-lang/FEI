#include <ctype.h>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "crypto.h"
#include "dados.h"

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
#else
#include <termios.h>
#include <unistd.h>
#endif

#define RST "\033[0m"
#define NEG "\033[1m"
#define VERDE "\033[92m"
#define VERM "\033[91m"
#define AMAR "\033[93m"
#define CIANO "\033[96m"

static const double TX_COMPRA[3] = {0.02, 0.01, 0.01};
static const double TX_VENDA[3] = {0.03, 0.02, 0.01};

static void habilitar_ansi(void)
{
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD modo = 0;
    if (GetConsoleMode(h, &modo))
        SetConsoleMode(h, modo | 0x0004);
#endif
}

static void ler_linha(const char *prompt, char *buf, size_t n)
{
    printf("%s", prompt);
    fflush(stdout);
    if (!fgets(buf, (int)n, stdin))
        exit(0);
    if (!strchr(buf, '\n'))
    {
        int c;
        while ((c = getchar()) != '\n' && c != EOF)
        {
        }
    }
    buf[strcspn(buf, "\r\n")] = 0;
}

static void ler_senha(const char *prompt, char *buf, size_t n)
{
    printf("%s", prompt);
    fflush(stdout);
#ifdef _WIN32
    size_t i = 0;
    int c;
    while ((c = _getch()) != '\r' && c != '\n')
    {
        if (c == 0 || c == 0xE0)
        {
            _getch();
            continue;
        }
        if (c == '\b')
        {
            if (i)
            {
                i--;
                printf("\b \b");
            }
        }
        else if (i < n - 1 && isprint(c))
        {
            buf[i++] = (char)c;
            putchar('*');
        }
    }
    buf[i] = 0;
#else
    struct termios ant, novo;
    tcgetattr(0, &ant);
    novo = ant;
    novo.c_lflag &= ~(tcflag_t)ECHO;
    tcsetattr(0, TCSANOW, &novo);
    char tmp[128];
    if (!fgets(tmp, sizeof tmp, stdin))
        tmp[0] = 0;
    tcsetattr(0, TCSANOW, &ant);
    tmp[strcspn(tmp, "\r\n")] = 0;
    strncpy(buf, tmp, n - 1);
    buf[n - 1] = 0;
#endif
    puts("");
}

static int ler_valor(const char *prompt, double *v)
{
    char b[64];
    ler_linha(prompt, b, sizeof b);
    for (char *c = b; *c; c++)
        if (*c == ',')
            *c = '.';
    char *fim;
    *v = strtod(b, &fim);
    if (fim == b || *fim || !(*v > 0) || *v > 1e12)
    {
        puts(VERM "Valor inválido." RST);
        return 0;
    }
    return 1;
}

static int cpf_valido(const char *c)
{
    if (strlen(c) != 11)
        return 0;
    int igual = 1;
    for (int i = 0; i < 11; i++)
    {
        if (!isdigit((unsigned char)c[i]))
            return 0;
        if (c[i] != c[0])
            igual = 0;
    }
    if (igual)
        return 0;
    for (int t = 9; t <= 10; t++)
    {
        int s = 0;
        for (int i = 0; i < t; i++)
            s += (c[i] - '0') * (t + 1 - i);
        int d = (s * 10) % 11;
        if (d == 10)
            d = 0;
        if (d != c[t] - '0')
            return 0;
    }
    return 1;
}

static int senha_valida(const char *s)
{
    if (strlen(s) != 6)
        return 0;
    for (int i = 0; i < 6; i++)
        if (!isdigit((unsigned char)s[i]))
            return 0;
    return 1;
}

static void hash_senha(const char *salt, const char *senha, char out[65])
{
    char tmp[64];
    snprintf(tmp, sizeof tmp, "%s%s", salt, senha);
    sha256_hex(tmp, out);
}

static const char *nivel(const Usuario *u, double *mult)
{
    if (u->ops >= 30)
    {
        *mult = 0.25;
        return "Whale";
    }
    if (u->ops >= 10)
    {
        *mult = 0.50;
        return "Pro";
    }
    *mult = 1.0;
    return "Iniciante";
}

static int confirmar_senha(const Usuario *u)
{
    char s[16], h[65];
    ler_senha("Senha: ", s, sizeof s);
    hash_senha(u->salt, s, h);
    if (strcmp(h, u->hash) != 0)
    {
        puts(VERM "Senha incorreta." RST);
        log_audit(u->cpf, "SENHA_INCORRETA_OPERACAO");
        return 0;
    }
    return 1;
}

static void mostrar_cotacoes(const double cot[3])
{
    for (int i = 0; i < 3; i++)
        printf("  %d) %-9s (%s)  R$ %.4f\n", i + 1, NOMES[i], SIMBOLOS[i], cot[i]);
}

static void ticker(void)
{
    double h[2][3];
    int n = historico(h, 2);
    if (n == 0)
        return;
    printf(CIANO);
    for (int i = 0; i < 3; i++)
    {
        double var = n == 2 ? (h[1][i] / h[0][i] - 1) * 100 : 0;
        printf("%s R$%.2f %s%s%.2f%%" CIANO "   ", SIMBOLOS[i], h[n - 1][i],
               var >= 0 ? VERDE "▲" : VERM "▼", "", var >= 0 ? var : -var);
    }
    puts(RST);
}

static void ver_saldo(const Usuario *u, const double cot[3])
{
    double mult, total = u->reais;
    const char *nv = nivel(u, &mult);
    printf("\n" NEG "Nome: %s\nCPF: %.3s.%.3s.%.3s-%s" RST "\n", u->nome, u->cpf, u->cpf + 3, u->cpf + 6, u->cpf + 9);
    printf("Nível: %s (taxas x%.2f, %d operações)\n\n", nv, mult, u->ops);
    printf("Reais:    R$ %.2f\n", u->reais);
    for (int i = 0; i < 3; i++)
    {
        double valor = u->cripto[i] * cot[i];
        total += valor;
        printf("%-9s %.8f  (R$ %.2f)", NOMES[i], u->cripto[i], valor);
        if (u->cripto[i] > 1e-9)
        {
            double lp = (cot[i] - u->pm[i]) * u->cripto[i];
            printf("  preço médio R$ %.2f  %s%+.2f" RST, u->pm[i], lp >= 0 ? VERDE : VERM, lp);
        }
        puts("");
    }
    printf(NEG "\nPatrimônio total: R$ %.2f" RST "\n", total);
}

static void ver_extrato(const Usuario *u)
{
    LinhaExtrato *v;
    int n = ler_extrato(u->cpf, &v);
    printf("\n" NEG "Nome: %s\nCPF: %s" RST "\n", u->nome, u->cpf);
    if (n == 0)
        puts("Nenhuma operação ainda.");
    for (int i = 0; i < n; i++)
    {
        int eh_real = strcmp(v[i].moeda, "REAL") == 0;
        printf("%s %c %.*f %s CT: %.2f TX: %.2f REAL: %.2f BTC: %.8f ETH: %.8f XRP: %.8f\n", v[i].data,
               v[i].sinal, eh_real ? 2 : 8, v[i].valor, v[i].moeda, v[i].ct, v[i].tx, v[i].reais, v[i].c[0],
               v[i].c[1], v[i].c[2]);
    }
    free(v);
}

static void depositar(Usuario *u, Banco *b)
{
    double v;
    if (!ler_valor("Valor do depósito: R$ ", &v))
        return;
    u->reais += v;
    registrar_extrato(u, '+', v, -1, 0, 0);
    salvar_usuarios(b);
    log_audit(u->cpf, "DEPOSITO");
    printf(VERDE "Depósito realizado." RST " Saldo: R$ %.2f\n", u->reais);
}

static void sacar(Usuario *u, Banco *b)
{
    double v;
    if (!ler_valor("Valor do saque: R$ ", &v))
        return;
    if (v > u->reais + 1e-9)
    {
        puts(VERM "Saldo insuficiente." RST);
        return;
    }
    u->reais -= v;
    registrar_extrato(u, '-', v, -1, 0, 0);
    salvar_usuarios(b);
    log_audit(u->cpf, "SAQUE");
    printf(VERDE "Saque realizado." RST " Saldo: R$ %.2f\n", u->reais);
}

static int escolher_moeda(const double cot[3])
{
    mostrar_cotacoes(cot);
    char b[16];
    ler_linha("Moeda (1-3): ", b, sizeof b);
    int m = atoi(b) - 1;
    if (m < 0 || m > 2)
    {
        puts(VERM "Moeda inválida." RST);
        return -1;
    }
    return m;
}

static void comprar(Usuario *u, Banco *b, const double cot[3])
{
    if (!confirmar_senha(u))
        return;
    int m = escolher_moeda(cot);
    if (m < 0)
        return;
    double mult, qtd;
    nivel(u, &mult);
    double pct = TX_COMPRA[m] * mult;

    char modo[8];
    puts("Como deseja comprar?\n  1) Informar a quantidade (ex: 0,001 " "BTC)\n  2) Informar quanto gastar em reais (ex: R$ 100)");
    ler_linha("Opção (1-2): ", modo, sizeof modo);
    int por_reais = atoi(modo) == 2;
    if (atoi(modo) != 1 && !por_reais)
    {
        puts(VERM "Opção inválida." RST);
        return;
    }

    if (por_reais)
    {
        double gasto;
        if (!ler_valor("Valor a gastar (taxa incluída): R$ ", &gasto))
            return;
        qtd = gasto / (cot[m] * (1.0 + pct)); /* fração comprada com esse valor */
    }
    else if (!ler_valor("Quantidade a comprar: ", &qtd))
        return;

    qtd = floor(qtd * 1e8 + 1e-6) / 1e8; /* precisão de 8 casas (1 satoshi), igual ao que é gravado */
    if (qtd < 1e-8)
    {
        puts(VERM "Valor muito pequeno: mínimo de 0,00000001." RST);
        return;
    }
    printf("Você receberá " NEG "%.8f %s" RST "\n", qtd, SIMBOLOS[m]);

    double custo = qtd * cot[m], taxa = custo * pct, total = custo + taxa;
    printf("Custo R$ %.2f + taxa %.2f%% (R$ %.2f) = " NEG "R$ %.2f" RST "\n", custo, pct * 100, taxa, total);
    if (total > u->reais + 1e-9)
    {
        puts(VERM "Saldo insuficiente." RST);
        return;
    }

    char r[8];
    ler_linha("Confirmar (s/n)? ", r, sizeof r);
    if (tolower((unsigned char)r[0]) != 's')
    {
        puts("Cancelado.");
        return;
    }

    u->pm[m] = (u->pm[m] * u->cripto[m] + total) / (u->cripto[m] + qtd); /* preço médio */
    u->reais -= total;
    u->cripto[m] += qtd;
    u->ops++;
    registrar_extrato(u, '+', qtd, m, cot[m], taxa);
    salvar_usuarios(b);
    log_audit(u->cpf, "COMPRA");
    printf(VERDE "Compra realizada: %.8f %s" RST "\n", qtd, SIMBOLOS[m]);
}

static void vender(Usuario *u, Banco *b, const double cot[3])
{
    if (!confirmar_senha(u))
        return;
    int m = escolher_moeda(cot);
    if (m < 0)
        return;
    double mult, qtd;
    nivel(u, &mult);
    double pct = TX_VENDA[m] * mult;
    printf("Você tem %.8f %s\n", u->cripto[m], SIMBOLOS[m]);
    if (!ler_valor("Quantidade a vender: ", &qtd))
        return;
    if (qtd > u->cripto[m] + 1e-12)
    {
        puts(VERM "Saldo de criptomoeda insuficiente." RST);
        return;
    }

    double bruto = qtd * cot[m], taxa = bruto * pct, liquido = bruto - taxa;
    double lucro = liquido - u->pm[m] * qtd;
    printf("Venda R$ %.2f - taxa %.2f%% (R$ %.2f) = " NEG "R$ %.2f" RST "\n", bruto, pct * 100, taxa, liquido);

    char r[8];
    ler_linha("Confirmar (s/n)? ", r, sizeof r);
    if (tolower((unsigned char)r[0]) != 's')
    {
        puts("Cancelado.");
        return;
    }

    u->cripto[m] -= qtd;
    if (u->cripto[m] < 1e-9)
    {
        u->cripto[m] = 0;
        u->pm[m] = 0;
    }
    u->reais += liquido;
    u->ops++;
    registrar_extrato(u, '-', qtd, m, cot[m], taxa);
    salvar_usuarios(b);
    log_audit(u->cpf, "VENDA");
    printf(VERDE "Venda realizada." RST " Resultado: %s%+.2f" RST "\n", lucro >= 0 ? VERDE : VERM, lucro);
}

static void atualizar_cotacao(double cot[3])
{
    for (int i = 0; i < 3; i++)
    {
        double var = ((double)rand() / RAND_MAX) * 0.10 - 0.05;
        double nova = cot[i] * (1 + var);
        printf("%-9s R$ %.4f -> R$ %.4f  %s%+.2f%%" RST "\n", NOMES[i], cot[i], nova, var >= 0 ? VERDE : VERM, var * 100);
        cot[i] = nova;
    }
    gravar_cotacao(cot);
}

static void grafico(void)
{
    double h[30][3];
    int n = historico(h, 30);
    if (n < 2)
    {
        puts("Atualize a cotação algumas vezes para formar o histórico.");
        return;
    }
    for (int m = 0; m < 3; m++)
    {
        double mn = h[0][m], mx = h[0][m];
        for (int i = 1; i < n; i++)
        {
            if (h[i][m] < mn)
                mn = h[i][m];
            if (h[i][m] > mx)
                mx = h[i][m];
        }
        int k = n < 7 ? n : 7;
        double soma = 0;
        for (int i = n - k; i < n; i++)
            soma += h[i][m];
        double mm = soma / k;
        printf("\n" NEG "%s" RST "  mín R$ %.2f  máx R$ %.2f  média(7) R$ %.2f  tendência: %s\n", NOMES[m], mn, mx, mm,
               h[n - 1][m] >= mm ? VERDE "ALTA" RST : VERM "BAIXA" RST);
        for (int row = 8; row >= 1; row--)
        {
            printf("  ");
            for (int i = 0; i < n; i++)
            {
                int nv = mx == mn ? 4 : 1 + (int)((h[i][m] - mn) / (mx - mn) * 7.0 + 0.5);
                printf(nv >= row ? (i > 0 && h[i][m] < h[i - 1][m] ? VERM "█" RST : VERDE "█" RST) : " ");
            }
            puts("");
        }
    }
}

static void sanear(char *s)
{
    for (; *s; s++)
        if (*s == '|' || *s == '"' || *s == '\\' || (unsigned char)*s < 32)
            *s = ' ';
}

static void cadastro(Banco *b)
{
    Usuario u;
    memset(&u, 0, sizeof u);
    char nome[128], cpf[64], s1[16], s2[16];

    ler_linha("Nome completo: ", nome, sizeof nome);
    sanear(nome);
    if (strlen(nome) < 3 || strlen(nome) > 63)
    {
        puts(VERM "Nome inválido." RST);
        return;
    }
    ler_linha("CPF (somente números): ", cpf, sizeof cpf);
    if (!cpf_valido(cpf))
    {
        puts(VERM "CPF inválido." RST);
        return;
    }
    if (buscar(b, cpf))
    {
        puts(VERM "CPF já cadastrado." RST);
        return;
    }
    ler_senha("Crie uma senha numérica de 6 dígitos: ", s1, sizeof s1);
    if (!senha_valida(s1))
    {
        puts(VERM "A senha deve ter exatamente 6 dígitos." RST);
        return;
    }
    ler_senha("Repita a senha: ", s2, sizeof s2);
    if (strcmp(s1, s2) != 0)
    {
        puts(VERM "As senhas não conferem." RST);
        return;
    }

    strcpy(u.nome, nome);
    strcpy(u.cpf, cpf);
    uint8_t salt[8], seg[10];
    bytes_aleatorios(salt, sizeof salt);
    for (int i = 0; i < 8; i++)
        snprintf(u.salt + 2 * i, 3, "%02x", salt[i]);
    hash_senha(u.salt, s1, u.hash);
    bytes_aleatorios(seg, sizeof seg);
    base32_encode(seg, sizeof seg, u.segredo);

    adicionar(b, &u);
    salvar_usuarios(b);
    log_audit(cpf, "CADASTRO");

    puts(VERDE "\nCadastro concluído!" RST);
    puts("\n==================================================");
    printf("  Investidor: %s\n", u.nome);
    puts("  Este é o seu TOKEN de acesso. GUARDE-O para logar:");
    printf(AMAR NEG "\n        %s\n" RST, u.segredo);
    puts("\n  Ele aparece somente agora. Sem ele você não consegue entrar.");
    puts("==================================================");
    puts("\nComo usar o token:");
    puts("  1. Abra o autenticador.html no navegador");
    puts("  2. Digite um nome para a conta e cole o token acima");
    puts("  3. No login, digite o código de 6 dígitos que o site mostrar");
    printf("\n(ou use o link otpauth://totp/ExchangeFEI:%s?secret=%s&issuer=ExchangeFEI no Google Authenticator)\n", cpf, u.segredo);
    ler_linha("\nJá anotou o token? Pressione ENTER para continuar...", cpf, sizeof cpf);
}

static Usuario *login(Banco *b)
{
    char cpf[64], senha[16], cod[16], h[65] = "";
    ler_linha("CPF (somente números): ", cpf, sizeof cpf);
    ler_senha("Senha (6 dígitos): ", senha, sizeof senha);
    Usuario *u = buscar(b, cpf);

    if (u && u->bloqueio > (long long)time(NULL))
    {
        printf(VERM "Conta bloqueada. Tente novamente em %lld s." RST "\n", u->bloqueio - (long long)time(NULL));
        return NULL;
    }
    if (u)
        hash_senha(u->salt, senha, h);
    if (!u || strcmp(h, u->hash) != 0)
    {
        puts(VERM "CPF ou senha inválidos." RST);
        if (u)
        {
            u->falhas++;
            log_audit(u->cpf, "LOGIN_FALHA");
            if (u->falhas >= 3)
            {
                u->bloqueio = (long long)time(NULL) + 60;
                u->falhas = 0;
                log_audit(u->cpf, "CONTA_BLOQUEADA");
                puts(VERM "3 tentativas erradas: conta bloqueada por 60 segundos." RST);
            }
            salvar_usuarios(b);
        }
        return NULL;
    }
    for (int t = 0; t < 3; t++)
    {
        ler_linha("Código do autenticador (6 dígitos): ", cod, sizeof cod);
        if (totp_verificar(u->segredo, cod))
        {
            u->falhas = 0;
            salvar_usuarios(b);
            log_audit(u->cpf, "LOGIN_OK");
            return u;
        }
        puts(VERM "Código inválido ou expirado." RST);
    }
    log_audit(u->cpf, "2FA_FALHA");
    return NULL;
}

static void menu_principal(Usuario *u, Banco *b, double cot[3])
{
    char op[16];
    for (;;)
    {
        double mult;
        printf("\n" NEG AMAR "=== EXCHANGE FEI ===" RST "  %s (%s)\n", u->nome, nivel(u, &mult));
        ticker();
        puts("1. Consultar saldo\n2. Consultar extrato\n3. Depositar\n4. Sacar\n5. Comprar criptomoedas\n"
             "6. Vender criptomoedas\n7. Atualizar cotação\n8. Sair\n9. Gráfico das cotações\n10. Exportar painel web");
        ler_linha("Opção: ", op, sizeof op);
        switch (atoi(op))
        {
        case 1:
            if (confirmar_senha(u))
                ver_saldo(u, cot);
            break;
        case 2:
            if (confirmar_senha(u))
                ver_extrato(u);
            break;
        case 3:
            depositar(u, b);
            break;
        case 4:
            sacar(u, b);
            break;
        case 5:
            comprar(u, b, cot);
            break;
        case 6:
            vender(u, b, cot);
            break;
        case 7:
            atualizar_cotacao(cot);
            break;
        case 8:
            log_audit(u->cpf, "LOGOUT");
            return;
        case 9:
            grafico();
            break;
        case 10:
            if (confirmar_senha(u))
            {
                exportar_json(u, cot, nivel(u, &mult));
                puts(VERDE "dados.json gerado. Abra no painel do site autenticador.html." RST);
            }
            break;
        default:
            puts(VERM "Opção inválida." RST);
        }
    }
}

int main(void)
{
    habilitar_ansi();
    srand((unsigned)time(NULL));
    Banco b;
    carregar_usuarios(&b);
    double cot[3];
    carregar_cotacao(cot);

    char op[16];
    for (;;)
    {
        puts("\n" NEG CIANO "  EXCHANGE DE CRIPTOMOEDAS · FEI" RST);
        ticker();
        puts("1. Entrar\n2. Cadastrar investidor\n3. Sair");
        ler_linha("Opção: ", op, sizeof op);
        switch (atoi(op))
        {
        case 1:
        {
            Usuario *u = login(&b);
            if (u)
                menu_principal(u, &b, cot);
            break;
        }
        case 2:
            cadastro(&b);
            break;
        case 3:
            free(b.v);
            return 0;
        default:
            puts(VERM "Opção inválida." RST);
        }
    }
}
