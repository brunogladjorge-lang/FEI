#include <stdio.h>
#include <string.h>
#include "../src/crypto.h"

static int falhas = 0;
#define CHECK(c, nome) do { if (c) printf("[ok]    %s\n", nome); else { printf("[FALHOU] %s\n", nome); falhas++; } } while (0)

int main(void) {
    char h[65];
    sha256_hex("abc", h);
    CHECK(strcmp(h, "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") == 0, "SHA-256 de 'abc'");

    uint8_t d[20];
    sha1((const uint8_t *)"abc", 3, d);
    CHECK(d[0] == 0xa9 && d[1] == 0x99 && d[2] == 0x3e && d[19] == 0x9d, "SHA-1 de 'abc'");

    /* Vetores da RFC 6238 (segredo "12345678901234567890", 6 ultimos digitos) */
    const uint8_t *k = (const uint8_t *)"12345678901234567890";
    CHECK(totp(k, 20, 1) == 287082, "TOTP RFC 6238 (t=59)");
    CHECK(totp(k, 20, 37037036ULL) == 81804, "TOTP RFC 6238 (t=1111111109)");
    CHECK(totp(k, 20, 41152263ULL) == 5924, "TOTP RFC 6238 (t=1234567890)");

    /* Base32: ida e volta */
    char b32[40]; uint8_t volta[10], orig[10] = {1,2,3,4,5,6,7,8,9,10};
    base32_encode(orig, 10, b32);
    CHECK(strlen(b32) == 16 && base32_decode(b32, volta, 10) == 10 && memcmp(orig, volta, 10) == 0, "Base32 ida e volta");

    printf(falhas ? "\n%d teste(s) falharam\n" : "\nTodos os testes passaram\n", falhas);
    return falhas != 0;
}
